
from copy import deepcopy
from statistics import mean
from pathlib import Path

from scenario_v42 import default_base_config, create_jobs_from_config, apply_bottleneck_deterioration
from simulator_v6 import Simulator
from report_v4 import ensure_dir, write_csv, write_json, build_summary, plot_overlap_sweep, plot_deterioration
from gantt_v5 import plot_gantt

POLICIES = ["FIFO", "HEFT", "BOS"]
SEEDS = [11, 19, 27, 35, 43, 51, 59, 67, 75]

OVERLAP_MULTIPLIERS = [0.0, 0.4, 0.8, 1.2, 1.6]
DETERIORATION_FACTORS = [1.0, 1.08, 1.15, 1.22, 1.3, 1.38, 1.5]


def run_single(policy, jobs, machine_count, experiment_name, seed, config):
    sim = Simulator(jobs, policy=policy, machine_count=machine_count, verbose=False)
    makespan = sim.run()
    summary = build_summary(sim, experiment_name=experiment_name, seed=seed, config=config)
    summary["makespan"] = makespan
    return sim, summary


def snapshot_case(output_dir):
    cfg = default_base_config()
    cfg["overlap_multiplier"] = 1.0

    snapshots = []
    seed = 11

    for policy in POLICIES:
        sim, summary = run_single(
            policy,
            create_jobs_from_config(cfg, seed=seed),
            cfg["machine_count"],
            "snapshot_case_v6",
            seed,
            cfg,
        )

        summary["policy"] = policy
        snapshots.append(summary)

        write_csv(
            sim.build_task_records(),
            output_dir / f"v6_snapshot_seed{seed}_{policy.lower()}_tasks.csv"
        )

        write_json(
            sim.decision_log,
            output_dir / f"v6_snapshot_seed{seed}_{policy.lower()}_decisions.json"
        )

        plot_gantt(
            sim,
            output_dir / f"v6_snapshot_seed{seed}_{policy.lower()}_gantt.png"
        )

    return snapshots


def overlap_sweep(output_dir):
    detail_rows = []
    agg_rows = []
    base = default_base_config()

    for overlap_multiplier in OVERLAP_MULTIPLIERS:
        cfg = deepcopy(base)
        cfg["overlap_multiplier"] = overlap_multiplier

        for policy in POLICIES:
            result_rows = []

            for seed in SEEDS:
                jobs = create_jobs_from_config(cfg, seed=seed)

                _, summary = run_single(
                    policy,
                    jobs,
                    cfg["machine_count"],
                    "overlap_sweep_v6",
                    seed,
                    cfg,
                )

                row = {
                    "policy": policy,
                    "overlap_multiplier": overlap_multiplier,
                    "makespan": summary["makespan"],
                    "machine_utilization": summary["machine_utilization"],
                }

                detail_rows.append(row)
                result_rows.append(row)

            agg_rows.append({
                "policy": policy,
                "overlap_multiplier": overlap_multiplier,
                "avg_makespan": round(mean(r["makespan"] for r in result_rows), 4),
                "avg_utilization": round(mean(r["machine_utilization"] for r in result_rows), 4),
            })

    write_csv(detail_rows, output_dir / "v6_overlap_detail.csv")
    write_csv(agg_rows, output_dir / "v6_overlap_summary.csv")

    plot_overlap_sweep([
        {"policy": r["policy"], "uniform_delta": r["overlap_multiplier"], "avg_makespan": r["avg_makespan"]}
        for r in agg_rows
    ], output_dir / "v6_overlap.png")

    return agg_rows


def deterioration_sweep(output_dir):
    detail_rows = []
    agg_rows = []
    base = default_base_config()
    base["overlap_multiplier"] = 1.0

    for factor in DETERIORATION_FACTORS:
        for policy in POLICIES:
            result_rows = []

            for seed in SEEDS:
                jobs = create_jobs_from_config(base, seed=seed)

                apply_bottleneck_deterioration(
                    jobs,
                    factor=factor,
                    stage_names=base["deterioration_stage_names"],
                    target_job_ids=base["deterioration_target_job_ids"],
                    seed=seed,
                )

                _, summary = run_single(
                    policy,
                    jobs,
                    base["machine_count"],
                    "deterioration_sweep_v6",
                    seed,
                    {**base, "deterioration_factor": factor},
                )

                row = {
                    "policy": policy,
                    "deterioration_factor": factor,
                    "makespan": summary["makespan"],
                    "machine_utilization": summary["machine_utilization"],
                }

                detail_rows.append(row)
                result_rows.append(row)

            agg_rows.append({
                "policy": policy,
                "deterioration_factor": factor,
                "avg_makespan": round(mean(r["makespan"] for r in result_rows), 4),
                "avg_utilization": round(mean(r["machine_utilization"] for r in result_rows), 4),
            })

    write_csv(detail_rows, output_dir / "v6_deterioration_detail.csv")
    write_csv(agg_rows, output_dir / "v6_deterioration_summary.csv")

    plot_deterioration(agg_rows, output_dir / "v6_deterioration.png")

    return agg_rows


def print_snapshot_results(snapshots):
    print("\n=== V6 Snapshot Case Results ===")
    for s in snapshots:
        print(
            f"  {s['policy']:<5} | makespan: {s['makespan']:>4}"
            f" | utilization: {s['machine_utilization']}"
        )


def print_table(title, rows, key):
    print(f"\n=== {title} ===")

    grouped = {}
    for r in rows:
        grouped.setdefault(r[key], []).append(r)

    for k in sorted(grouped.keys()):
        print(f"\n{key} = {k}")
        fifo = next(r for r in grouped[k] if r["policy"] == "FIFO")
        heft = next((r for r in grouped[k] if r["policy"] == "HEFT"), None)

        for r in grouped[k]:
            base = fifo["avg_makespan"]
            imp = (base - r["avg_makespan"]) / base * 100 if base else 0
            extra = f" | vs FIFO: {round(imp, 2)}%"
            if r["policy"] == "BOS" and heft is not None:
                heft_imp = (heft["avg_makespan"] - r["avg_makespan"]) / heft["avg_makespan"] * 100 if heft["avg_makespan"] else 0
                extra += f" | vs HEFT: {round(heft_imp, 2)}%"

            print(
                f"  {r['policy']:<5} | avg_makespan: {r['avg_makespan']:>7}"
                f" | util: {r['avg_utilization']}"
                f"{extra}"
            )


def main():
    output_dir = ensure_dir(Path("v6_outputs"))

    overlap_summary = overlap_sweep(output_dir)
    deterioration_summary = deterioration_sweep(output_dir)
    snapshots = snapshot_case(output_dir)

    final_summary = {
        "version": "v6",
        "overlap": overlap_summary,
        "deterioration": deterioration_summary,
        "snapshot": snapshots,
    }

    write_json(final_summary, output_dir / "v6_summary.json")

    print_snapshot_results(snapshots)
    print_table("V6 Overlap Sweep Summary", overlap_summary, key="overlap_multiplier")
    print_table("V6 Deterioration Sweep Summary", deterioration_summary, key="deterioration_factor")

    print(f"\n✅ V6 completed")
    print(f"📁 Outputs: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
