def compute_D(task, memo=None):
    if memo is None:
        memo = {}

    if task in memo:
        return memo[task]

    # Residual-DAG-lite version:
    # successors that are already done are ignored.
    active_succ = [s for s in task.succ if s.status != "done"]
    if not active_succ:
        memo[task] = task.p
        task.D = task.p
        return task.D

    max_succ = 0
    for succ_task in active_succ:
        delta = task.delta_to_succ.get(succ_task, 0)
        val = compute_D(succ_task, memo) - delta
        max_succ = max(max_succ, val)

    memo[task] = task.p + max_succ
    task.D = memo[task]
    return task.D



def bos_select(ready_tasks):
    memo = {}
    for task in ready_tasks:
        compute_D(task, memo)

    # Prefer higher D; use earlier ready_since as a stable tie-breaker.
    ready_tasks.sort(key=lambda x: (-x.D, x.ready_since, x.id))
    return ready_tasks[0]
