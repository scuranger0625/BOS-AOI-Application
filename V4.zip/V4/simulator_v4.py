from scheduler_bos_v2 import bos_select
from scheduler_fifo_v2 import fifo_select
from scheduler_heft_v4 import heft_select
from model_v2 import Machine


class Simulator:
    def __init__(self, jobs, policy="FIFO", machine_count=2, verbose=False):
        self.jobs = jobs
        self.policy = policy.upper()
        self.time = 0
        self.verbose = verbose

        self.machines = [Machine(f"M{i + 1}") for i in range(machine_count)]
        self.all_tasks = [task for job in jobs for task in job.tasks]

        self.event_log = []
        self.assignment_log = []
        self.decision_log = []

    def log(self, message):
        if self.verbose:
            print(message)

    def record_event(self, event_type, **payload):
        row = {"time": self.time, "event": event_type}
        row.update(payload)
        self.event_log.append(row)

    def all_done(self):
        return all(task.status == "done" for task in self.all_tasks)

    def process_completions(self):
        for machine in self.machines:
            task = machine.current_task
            if task is None:
                continue
            if task.finish_time == self.time:
                task.status = "done"
                machine.current_task = None
                self.record_event(
                    "complete",
                    task_id=task.id,
                    job_id=task.job_id,
                    machine_id=machine.id,
                    start_time=task.start_time,
                    finish_time=task.finish_time,
                )
                self.log(f"t={self.time} COMPLETE {task.id} on {machine.id}")

    def refresh_ready_tasks(self):
        ready = []
        for task in self.all_tasks:
            if task.is_ready(self.time):
                if task.status == "waiting":
                    task.status = "ready"
                    task.ready_since = self.time
                    self.record_event(
                        "activate",
                        task_id=task.id,
                        job_id=task.job_id,
                        ready_since=task.ready_since,
                        earliest_ready_time=task.earliest_ready_time(),
                    )
                ready.append(task)
        return ready

    def select_task(self, ready_tasks):
        ready_snapshot = list(ready_tasks)
        if self.policy == "BOS":
            task = bos_select(ready_tasks)
            candidates = [{"task_id": t.id, "priority": t.D, "priority_name": "D", "ready_since": t.ready_since}
                          for t in sorted(ready_snapshot, key=lambda x: (-x.D, x.ready_since, x.id))]
        elif self.policy == "HEFT":
            task = heft_select(ready_tasks)
            candidates = [{"task_id": t.id, "priority": getattr(t, "static_rank", t.p), "priority_name": "static_rank", "ready_since": t.ready_since}
                          for t in sorted(ready_snapshot, key=lambda x: (-getattr(x, "static_rank", x.p), x.ready_since, x.id))]
        else:
            task = fifo_select(ready_tasks)
            candidates = [{"task_id": t.id, "priority": t.ready_since, "priority_name": "ready_since", "ready_since": t.ready_since}
                          for t in sorted(ready_snapshot, key=lambda x: (x.ready_since, x.job_release_time, x.id))]

        self.decision_log.append({
            "time": self.time,
            "policy": self.policy,
            "selected_task": task.id,
            "ready_candidates": candidates,
        })
        return task

    def assign(self, task, machine):
        task.status = "running"
        task.start_time = self.time
        task.finish_time = self.time + task.p
        task.assigned_machine = machine
        machine.current_task = task
        self.assignment_log.append({
            "time": self.time,
            "task_id": task.id,
            "job_id": task.job_id,
            "machine_id": machine.id,
            "processing_time": task.p,
            "ready_since": task.ready_since,
            "start_time": task.start_time,
            "finish_time": task.finish_time,
            "policy": self.policy,
            "D": getattr(task, "D", None),
            "static_rank": getattr(task, "static_rank", None),
        })
        self.record_event(
            "assign",
            task_id=task.id,
            job_id=task.job_id,
            machine_id=machine.id,
            processing_time=task.p,
            ready_since=task.ready_since,
            start_time=task.start_time,
            finish_time=task.finish_time,
            D=getattr(task, "D", None),
            static_rank=getattr(task, "static_rank", None),
        )

    def next_event_time(self):
        candidate_times = []
        for machine in self.machines:
            task = machine.current_task
            if task is not None and task.finish_time > self.time:
                candidate_times.append(task.finish_time)
        for task in self.all_tasks:
            if task.status not in ("waiting", "ready"):
                continue
            ready_t = task.earliest_ready_time()
            if ready_t is not None and ready_t > self.time:
                candidate_times.append(ready_t)
        return min(candidate_times) if candidate_times else None

    def build_task_records(self):
        rows = []
        sorted_tasks = sorted(self.all_tasks, key=lambda x: ((x.start_time or 10**9), x.job_id, x.id))
        for task in sorted_tasks:
            rows.append({
                "task_id": task.id,
                "job_id": task.job_id,
                "machine_id": task.assigned_machine.id if task.assigned_machine else None,
                "processing_time": task.p,
                "ready_since": task.ready_since,
                "start_time": task.start_time,
                "finish_time": task.finish_time,
                "job_release_time": task.job_release_time,
                "policy": self.policy,
            })
        return rows

    def run(self):
        while not self.all_done():
            self.process_completions()
            while True:
                ready = self.refresh_ready_tasks()
                idle_machines = [m for m in self.machines if m.current_task is None]
                if not ready or not idle_machines:
                    break
                task = self.select_task(ready)
                machine = idle_machines[0]
                self.assign(task, machine)
            if self.all_done():
                break
            next_time = self.next_event_time()
            if next_time is None:
                raise RuntimeError("Simulation is stuck: no future activation/completion event exists.")
            self.record_event("jump", from_time=self.time, to_time=next_time)
            self.time = next_time
        makespan = max(task.finish_time for task in self.all_tasks)
        self.record_event("finish", makespan=makespan, policy=self.policy)
        return makespan
