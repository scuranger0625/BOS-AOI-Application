import random
from model_v2 import Task, Job


BASE_TEMPLATE = {
    "T1": 2,
    "T2": 3,
    "T3": 5,
    "T4": 4,
    "T5": 3,
    "T6": 1,
}

EDGES = [
    ("T1", "T2"),
    ("T2", "T3"),
    ("T2", "T4"),
    ("T3", "T5"),
    ("T4", "T5"),
    ("T5", "T6"),
]


def create_job(job_id, release, duration_scale=1.0, uniform_delta=0, branch_heavy_factor=1.0):
    job = Job(job_id, release)

    p = {k: max(1, int(round(v * duration_scale))) for k, v in BASE_TEMPLATE.items()}
    p["T3"] = max(1, int(round(p["T3"] * branch_heavy_factor)))
    p["T4"] = max(1, int(round(p["T4"] * branch_heavy_factor)))

    tasks = {
        name: Task(f"{job_id}_{name}", job_id, p[name], release if name == "T1" else 0)
        for name in BASE_TEMPLATE
    }

    for src, dst in EDGES:
        tasks[src].succ.append(tasks[dst])
        tasks[dst].pred.append(tasks[src])
        tasks[src].delta_to_succ[tasks[dst]] = uniform_delta

    job.tasks = [tasks[f"T{i}"] for i in range(1, 7)]
    return job


def create_jobs_from_config(config, seed=0):
    rng = random.Random(seed)
    jobs = []
    for idx in range(config.get("job_count", 4)):
        job_id = chr(ord("A") + idx)
        base_release = config.get("release_gap", 3) * idx
        release_jitter = config.get("release_jitter", 0)
        jitter = rng.randint(0, release_jitter) if release_jitter > 0 else 0
        release = base_release + jitter

        scale_low, scale_high = config.get("duration_scale_range", (1.0, 1.0))
        duration_scale = rng.uniform(scale_low, scale_high)

        heavy_jobs = set(config.get("heavy_jobs", []))
        branch_heavy_factor = config.get("base_branch_heavy_factor", 1.0)
        if job_id in heavy_jobs:
            branch_heavy_factor *= config.get("heavy_multiplier", 1.4)

        jobs.append(
            create_job(
                job_id=job_id,
                release=release,
                duration_scale=duration_scale,
                uniform_delta=config.get("uniform_delta", 0),
                branch_heavy_factor=branch_heavy_factor,
            )
        )
    return jobs


def apply_bottleneck_deterioration(jobs, factor=1.5, stage_names=("T3", "T4"), target_job_id=None):
    """Static version of deterioration for experiment design.
    Inflates mid-level branch stages before simulation starts.
    """
    for job in jobs:
        if target_job_id is not None and job.id != target_job_id:
            continue
        for task in job.tasks:
            suffix = task.id.split("_")[-1]
            if suffix in stage_names:
                task.p = max(1, int(round(task.p * factor)))


def default_base_config():
    return {
        "job_count": 4,
        "release_gap": 4,
        "release_jitter": 1,
        "duration_scale_range": (0.9, 1.1),
        "uniform_delta": 0,
        "base_branch_heavy_factor": 1.0,
        "heavy_jobs": ["C"],
        "heavy_multiplier": 1.35,
        "machine_count": 2,
    }
