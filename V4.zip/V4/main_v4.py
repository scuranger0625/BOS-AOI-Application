from copy import deepcopy
from statistics import mean
from pathlib import Path

from scenario_v4 import default_base_config, create_jobs_from_config, apply_bottleneck_deterioration
from simulator_v4 import Simulator
from report_v4 import ensure_dir, write_csv, write_json, build_summary, plot_overlap_sweep, plot_deterioration


POLICIES = ["FIFO", "HEFT", "BOS"]
SEEDS = [11, 19, 27, 35, 43]
DELTA_VALUES = [0, 1, 2, 3]
DETERIORATION_FACTORS = [1.0, 1.2, 1.5, 1.8]


def run_single(policy, jobs, machine_count, experiment_name, seed, config):
    sim = Simulator(jobs, policy=policy, machine_count=machine_count, verbose=False)
    makespan = sim.run()
    summary = build_summary(sim, experiment_name=experiment_name, seed=seed, config=config)
    summary["makespan"] = makespan
    return sim, summary


def print_policy_table(title, rows, group_key, value_key="avg_makespan"):
    print(f"\n=== {title} ===")
    grouped = {}
    for row in rows:
        grouped.setdefault(row[group_key], []).append(row)

    for key in sorted(grouped.keys()):
        print(f"\n{group_key} = {key}")
        for row in grouped[key]:
            util = row.get("avg_utilization", row.get("machine_utilization", "-"))
            print(
                f"  {row['policy']:<5} | {value_key}: {row[value_key]:>6}"
                f" | utilization: {util}"
            )


def print_snapshot_results(snapshots):
    print("\n=== Snapshot Case Results ===")
    for summary in snapshots:
        print(
            f"  {summary['policy']:<5} | makespan: {summary['makespan']:>3}"
            f" | utilization: {summary['machine_utilization']}"
        )


def overlap_sweep(output_dir):
    detail_rows = []
    agg_rows = []
    base = default_base_config()
    for delta in DELTA_VALUES:
        cfg = deepcopy(base)
        cfg["uniform_delta"] = delta
        for policy in POLICIES:
            result_rows = []
            for seed in SEEDS:
                jobs = create_jobs_from_config(cfg, seed=seed)
                _, summary = run_single(policy, jobs, cfg["machine_count"], "overlap_sweep", seed, cfg)
                row = {
                    "experiment": "overlap_sweep",
                    "seed": seed,
                    "policy": policy,
                    "uniform_delta": delta,
                    "makespan": summary["makespan"],
                    "machine_utilization": summary["machine_utilization"],
                }
                detail_rows.append(row)
                result_rows.append(row)
            agg_rows.append({
                "experiment": "overlap_sweep",
                "policy": policy,
                "uniform_delta": delta,
                "avg_makespan": round(mean(r["makespan"] for r in result_rows), 4),
                "avg_utilization": round(mean(r["machine_utilization"] for r in result_rows), 4),
            })
    write_csv(detail_rows, output_dir / "overlap_sweep_detail.csv")
    write_csv(agg_rows, output_dir / "overlap_sweep_summary.csv")
    plot_overlap_sweep(agg_rows, output_dir / "overlap_sweep.png")
    return detail_rows, agg_rows


def deterioration_sweep(output_dir):
    detail_rows = []
    agg_rows = []
    base = default_base_config()
    base["uniform_delta"] = 1
    for factor in DETERIORATION_FACTORS:
        for policy in POLICIES:
            result_rows = []
            for seed in SEEDS:
                jobs = create_jobs_from_config(base, seed=seed)
                apply_bottleneck_deterioration(jobs, factor=factor, stage_names=("T3", "T4"), target_job_id="C")
                _, summary = run_single(policy, jobs, base["machine_count"], "deterioration_sweep", seed, {
                    **base,
                    "deterioration_factor": factor,
                    "target_job_id": "C",
                })
                row = {
                    "experiment": "deterioration_sweep",
                    "seed": seed,
                    "policy": policy,
                    "deterioration_factor": factor,
                    "makespan": summary["makespan"],
                    "machine_utilization": summary["machine_utilization"],
                }
                detail_rows.append(row)
                result_rows.append(row)
            agg_rows.append({
                "experiment": "deterioration_sweep",
                "policy": policy,
                "deterioration_factor": factor,
                "avg_makespan": round(mean(r["makespan"] for r in result_rows), 4),
                "avg_utilization": round(mean(r["machine_utilization"] for r in result_rows), 4),
            })
    write_csv(detail_rows, output_dir / "deterioration_detail.csv")
    write_csv(agg_rows, output_dir / "deterioration_summary.csv")
    plot_deterioration(agg_rows, output_dir / "deterioration_sweep.png")
    return detail_rows, agg_rows


def snapshot_case(output_dir):
    cfg = default_base_config()
    cfg["uniform_delta"] = 1
    snapshots = []
    for policy in POLICIES:
        sim, summary = run_single(
            policy,
            create_jobs_from_config(cfg, seed=11),
            cfg["machine_count"],
            "snapshot_case",
            11,
            cfg,
        )
        summary["policy"] = policy
        snapshots.append(summary)
        write_csv(sim.build_task_records(), output_dir / f"snapshot_{policy.lower()}_tasks.csv")
        write_csv(sim.assignment_log, output_dir / f"snapshot_{policy.lower()}_assignments.csv")
        write_json(sim.decision_log, output_dir / f"snapshot_{policy.lower()}_decisions.json")
    write_json(snapshots, output_dir / "snapshot_case_summary.json")
    return snapshots


def main():
    output_dir = ensure_dir(Path("v4_outputs"))
    _, overlap_summary = overlap_sweep(output_dir)
    _, deterioration_summary = deterioration_sweep(output_dir)
    snapshots = snapshot_case(output_dir)

    final_summary = {
        "policies": POLICIES,
        "seeds": SEEDS,
        "delta_values": DELTA_VALUES,
        "deterioration_factors": DETERIORATION_FACTORS,
        "overlap_sweep_summary": overlap_summary,
        "deterioration_summary": deterioration_summary,
        "snapshot_case": snapshots,
    }
    write_json(final_summary, output_dir / "v4_summary.json")

    print_snapshot_results(snapshots)
    print_policy_table("Overlap Sweep Summary", overlap_summary, group_key="uniform_delta")
    print_policy_table("Deterioration Sweep Summary", deterioration_summary, group_key="deterioration_factor")
    print(f"\nV4 outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
