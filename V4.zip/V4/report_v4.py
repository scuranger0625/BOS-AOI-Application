from pathlib import Path
import csv
import json
import matplotlib.pyplot as plt


def ensure_dir(path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_csv(rows, filepath):
    filepath = Path(filepath)
    if not rows:
        filepath.write_text("", encoding="utf-8")
        return filepath
    fieldnames = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with filepath.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return filepath


def write_json(obj, filepath):
    filepath = Path(filepath)
    filepath.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return filepath


def build_summary(sim, experiment_name=None, seed=None, config=None):
    records = sim.build_task_records()
    makespan = max(row["finish_time"] for row in records)
    total_processing = sum(row["processing_time"] for row in records)
    machine_count = len(sim.machines)
    utilization = total_processing / (machine_count * makespan) if makespan else 0
    out = {
        "experiment": experiment_name,
        "seed": seed,
        "policy": sim.policy,
        "makespan": makespan,
        "total_processing_time": total_processing,
        "machine_count": machine_count,
        "machine_utilization": round(utilization, 4),
    }
    if config is not None:
        out["config"] = config
    return out


def plot_overlap_sweep(rows, filepath):
    filepath = Path(filepath)
    grouped = {}
    for row in rows:
        key = row["policy"]
        grouped.setdefault(key, {"x": [], "y": []})
        grouped[key]["x"].append(row["uniform_delta"])
        grouped[key]["y"].append(row["avg_makespan"])
    fig, ax = plt.subplots(figsize=(10, 5))
    for policy, pts in sorted(grouped.items()):
        paired = sorted(zip(pts["x"], pts["y"]), key=lambda x: x[0])
        ax.plot([x for x, _ in paired], [y for _, y in paired], marker="o", label=policy)
    ax.set_xlabel("Uniform overlap allowance δ")
    ax.set_ylabel("Average makespan")
    ax.set_title("V4 Overlap Sensitivity")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(filepath, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return filepath


def plot_deterioration(rows, filepath):
    filepath = Path(filepath)
    grouped = {}
    for row in rows:
        grouped.setdefault(row["policy"], {"x": [], "y": []})
        grouped[row["policy"]]["x"].append(row["deterioration_factor"])
        grouped[row["policy"]]["y"].append(row["avg_makespan"])
    fig, ax = plt.subplots(figsize=(10, 5))
    for policy, pts in sorted(grouped.items()):
        paired = sorted(zip(pts["x"], pts["y"]), key=lambda x: x[0])
        ax.plot([x for x, _ in paired], [y for _, y in paired], marker="o", label=policy)
    ax.set_xlabel("Bottleneck deterioration factor")
    ax.set_ylabel("Average makespan")
    ax.set_title("V4 Bottleneck Deterioration")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(filepath, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return filepath
