class Task:
    def __init__(self, id, job_id, p, release_time=0):
        self.id = id
        self.job_id = job_id
        self.p = p
        self.release_time = release_time
        self.job_release_time = release_time

        self.pred = []
        self.succ = []
        self.delta_to_succ = {}

        self.status = "waiting"
        self.start_time = None
        self.finish_time = None
        self.assigned_machine = None

        self.D = 0

    def is_ready(self, current_time):
        # 🔴 新增：job-level release
        if current_time < self.job_release_time:
            return False

        for j in self.pred:
            if j.finish_time is None:
                return False

            delta = j.delta_to_succ.get(self, 0)
            if current_time < j.start_time + j.p - delta:
                return False

        return True


class Job:
    def __init__(self, job_id, release_time):
        self.id = job_id
        self.release_time = release_time
        self.tasks = []


class Machine:
    def __init__(self, id):
        self.id = id
        self.current_task = None


class Event:
    def __init__(self, time, type, payload=None):
        self.time = time
        self.type = type
        self.payload = payload