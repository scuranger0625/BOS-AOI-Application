from scenario import create_jobs
from simulator import Simulator

print("===== FIFO =====")
jobs = create_jobs()
sim = Simulator(jobs, policy="FIFO")
sim.run()

print("\n===== BOS =====")
jobs = create_jobs()
sim = Simulator(jobs, policy="BOS")
sim.run()