from scheduler_bos import bos_select
from scheduler_fifo import fifo_select
from model import Machine


class Simulator:
    def __init__(self, jobs, policy="FIFO"):
        self.jobs = jobs
        self.policy = policy
        self.time = 0

        self.machines = [Machine("M1"), Machine("M2")]
        self.event_queue = []

        self.all_tasks = [t for j in jobs for t in j.tasks]

    def all_done(self):
        return all(t.status == "done" for t in self.all_tasks)

    def get_ready(self):
        ready = []
        for t in self.all_tasks:
            # 只有 waiting / ready 的 task 才可能被派工
            if t.status in ("waiting", "ready") and t.is_ready(self.time):
                t.status = "ready"
                ready.append(t)
        return ready

    def assign(self, task, machine):
        task.status = "running"
        task.start_time = self.time
        task.assigned_machine = machine

        machine.current_task = task

        finish_time = self.time + task.p
        self.event_queue.append((finish_time, task))

        print(f"t={self.time} {task.id} -> {machine.id}")

    def process_events(self):
        for (t, task) in list(self.event_queue):
            if t == self.time:
                task.status = "done"
                task.finish_time = self.time

                m = task.assigned_machine
                m.current_task = None

                self.event_queue.remove((t, task))

    def run(self):
        while not self.all_done():
            self.process_events()

            ready = self.get_ready()
            idle = [m for m in self.machines if m.current_task is None]

            while ready and idle:
                if self.policy == "BOS":
                    t = bos_select(ready)
                else:
                    t = fifo_select(ready)

                m = idle.pop(0)
                self.assign(t, m)
                ready.remove(t)

            self.time += 1

        print(f"\nMakespan = {self.time}")