def fifo_select(ready_tasks):
    ready_tasks.sort(key=lambda x: x.release_time)
    return ready_tasks[0]