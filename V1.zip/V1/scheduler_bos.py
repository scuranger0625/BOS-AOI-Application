def compute_D(task):
    if not task.succ:
        return task.p

    max_succ = 0
    for j in task.succ:
        delta = task.delta_to_succ.get(j, 0)
        val = compute_D(j) - delta
        max_succ = max(max_succ, val)

    task.D = task.p + max_succ
    return task.D


def bos_select(ready_tasks):
    for t in ready_tasks:
        compute_D(t)

    ready_tasks.sort(key=lambda x: x.D, reverse=True)
    return ready_tasks[0]