
from pathlib import Path
from scenario_v2 import create_jobs
from simulator_v3 import Simulator
from report_v3 import (
    ensure_dir,
    write_csv,
    write_json,
    build_summary,
    save_gantt,
    save_comparison_gantt,
)


def run_one(policy, output_dir):
    jobs = create_jobs()
    sim = Simulator(jobs, policy=policy, verbose=True)
    makespan = sim.run()

    summary = build_summary(sim)
    summary["makespan"] = makespan

    write_csv(sim.build_task_records(), output_dir / f"{policy.lower()}_tasks.csv")
    write_csv(sim.assignment_log, output_dir / f"{policy.lower()}_assignments.csv")
    write_csv(sim.event_log, output_dir / f"{policy.lower()}_events.csv")
    write_json(sim.decision_log, output_dir / f"{policy.lower()}_decisions.json")
    write_json(summary, output_dir / f"{policy.lower()}_summary.json")
    save_gantt(sim, output_dir / f"{policy.lower()}_gantt.png")
    return sim, summary


def main():
    output_dir = ensure_dir(Path("v3_outputs"))

    print("===== FIFO V3 =====")
    fifo_sim, fifo_summary = run_one("FIFO", output_dir)

    print("\n===== BOS V3 =====")
    bos_sim, bos_summary = run_one("BOS", output_dir)

    save_comparison_gantt(fifo_sim, bos_sim, output_dir / "fifo_vs_bos_gantt.png")

    comparison = {
        "FIFO_makespan": fifo_summary["makespan"],
        "BOS_makespan": bos_summary["makespan"],
        "improvement": fifo_summary["makespan"] - bos_summary["makespan"],
        "improvement_ratio": round(
            (fifo_summary["makespan"] - bos_summary["makespan"]) / fifo_summary["makespan"], 4
        ) if fifo_summary["makespan"] else 0,
    }
    write_json(comparison, output_dir / "comparison_summary.json")

    print("\n===== COMPARISON =====")
    print(comparison)
    print(f"\nOutputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
