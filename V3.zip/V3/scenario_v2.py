from model_v2 import Task, Job


def create_job(job_id, release, heavy=False):
    job = Job(job_id, release)

    p = {
        "T1": 2,
        "T2": 3,
        "T3": 5,
        "T4": 4,
        "T5": 3,
        "T6": 1,
    }

    if heavy:
        p["T3"] = 6
        p["T4"] = 5

    T1 = Task(f"{job_id}_T1", job_id, p["T1"], release)
    T2 = Task(f"{job_id}_T2", job_id, p["T2"])
    T3 = Task(f"{job_id}_T3", job_id, p["T3"])
    T4 = Task(f"{job_id}_T4", job_id, p["T4"])
    T5 = Task(f"{job_id}_T5", job_id, p["T5"])
    T6 = Task(f"{job_id}_T6", job_id, p["T6"])

    # DAG
    T1.succ = [T2]
    T2.pred = [T1]

    T2.succ = [T3, T4]
    T3.pred = [T2]
    T4.pred = [T2]

    T3.succ = [T5]
    T4.succ = [T5]
    T5.pred = [T3, T4]

    T5.succ = [T6]
    T6.pred = [T5]

    # edge-wise time overlap allowance δ_ij
    T2.delta_to_succ[T3] = 1
    T2.delta_to_succ[T4] = 1

    job.tasks = [T1, T2, T3, T4, T5, T6]
    return job



def create_jobs():
    return [
        create_job("A", 0),
        create_job("B", 2),
        create_job("C", 4, heavy=True),
        create_job("U", 12),
    ]
