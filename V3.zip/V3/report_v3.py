
from pathlib import Path
import csv
import json
import matplotlib.pyplot as plt


def ensure_dir(path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_csv(rows, filepath):
    filepath = Path(filepath)
    if not rows:
        filepath.write_text("", encoding="utf-8")
        return filepath

    fieldnames = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)

    with filepath.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return filepath


def write_json(obj, filepath):
    filepath = Path(filepath)
    filepath.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return filepath


def build_summary(sim):
    records = sim.build_task_records()
    makespan = max(row["finish_time"] for row in records)
    total_processing = sum(row["processing_time"] for row in records)
    machine_count = len(sim.machines)
    utilization = total_processing / (machine_count * makespan) if makespan else 0

    by_job = {}
    for row in records:
        job = row["job_id"]
        info = by_job.setdefault(
            job,
            {
                "job_id": job,
                "release_time": row["job_release_time"],
                "first_start": row["start_time"],
                "completion_time": row["finish_time"],
            },
        )
        info["first_start"] = min(info["first_start"], row["start_time"])
        info["completion_time"] = max(info["completion_time"], row["finish_time"])

    job_summary = []
    for job_id in sorted(by_job):
        info = by_job[job_id]
        job_summary.append(
            {
                "job_id": job_id,
                "release_time": info["release_time"],
                "first_start": info["first_start"],
                "completion_time": info["completion_time"],
                "job_flow_time": info["completion_time"] - info["release_time"],
            }
        )

    return {
        "policy": sim.policy,
        "makespan": makespan,
        "total_processing_time": total_processing,
        "machine_count": machine_count,
        "machine_utilization": round(utilization, 4),
        "job_summary": job_summary,
    }


def save_gantt(sim, filepath):
    records = sim.build_task_records()
    filepath = Path(filepath)

    machine_ids = [m.id for m in sim.machines]
    machine_y = {mid: i for i, mid in enumerate(machine_ids)}

    fig, ax = plt.subplots(figsize=(12, 4.8))

    for row in records:
        y = machine_y[row["machine_id"]]
        width = row["finish_time"] - row["start_time"]
        ax.barh(y, width, left=row["start_time"], height=0.55)
        ax.text(
            row["start_time"] + width / 2,
            y,
            row["task_id"],
            ha="center",
            va="center",
            fontsize=8,
        )

    ax.set_yticks(range(len(machine_ids)))
    ax.set_yticklabels(machine_ids)
    ax.set_xlabel("Time")
    ax.set_ylabel("Machine")
    ax.set_title(f"Gantt Chart - {sim.policy} (Makespan={max(r['finish_time'] for r in records)})")
    ax.grid(axis="x", alpha=0.3)

    fig.tight_layout()
    fig.savefig(filepath, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return filepath


def save_comparison_gantt(sim_a, sim_b, filepath):
    filepath = Path(filepath)
    sims = [sim_a, sim_b]

    fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(12, 8), sharex=False)
    if len(sims) == 1:
        axes = [axes]

    for ax, sim in zip(axes, sims):
        records = sim.build_task_records()
        machine_ids = [m.id for m in sim.machines]
        machine_y = {mid: i for i, mid in enumerate(machine_ids)}

        for row in records:
            y = machine_y[row["machine_id"]]
            width = row["finish_time"] - row["start_time"]
            ax.barh(y, width, left=row["start_time"], height=0.55)
            ax.text(
                row["start_time"] + width / 2,
                y,
                row["task_id"],
                ha="center",
                va="center",
                fontsize=8,
            )

        makespan = max(r["finish_time"] for r in records)
        ax.set_yticks(range(len(machine_ids)))
        ax.set_yticklabels(machine_ids)
        ax.set_xlabel("Time")
        ax.set_ylabel("Machine")
        ax.set_title(f"{sim.policy} (Makespan={makespan})")
        ax.grid(axis="x", alpha=0.3)

    fig.tight_layout()
    fig.savefig(filepath, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return filepath
