import random
from model_v2 import Task, Job

# V4.2 goal:
# - create stronger conflict between static longest-downstream ranking (HEFT-like)
#   and overlap-adjusted / bottleneck-aware ranking (BOS)
# - amplify the "moderate deterioration" regime where BOS should adapt earlier
# - keep the same simulator/scheduler core untouched

ARCHETYPES = {
    "anchor": {
        # True bottleneck job: merge-heavy, low overlap on the heavy path.
        "durations": {
            "T1": 2, "T2": 4, "T3": 9, "T4": 8, "T5": 8, "T6": 6, "T7": 3,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T3", "T5"),
            ("T4", "T5"),
            ("T5", "T6"),
            ("T6", "T7"),
        ],
        "delta_map": {
            ("T1", "T2"): 0,
            ("T2", "T3"): 0,
            ("T2", "T4"): 0,
            ("T3", "T5"): 0,
            ("T4", "T5"): 0,
            ("T5", "T6"): 0,
            ("T6", "T7"): 0,
        },
    },
    "trap": {
        # Looks long statically, but large overlap makes its effective downstream pressure smaller.
        # HEFT-like ranking tends to overvalue this job.
        "durations": {
            "T1": 2, "T2": 5, "T3": 11, "T4": 10, "T5": 5, "T6": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T3", "T5"),
            ("T4", "T5"),
            ("T5", "T6"),
        ],
        "delta_map": {
            ("T1", "T2"): 1,
            ("T2", "T3"): 6,
            ("T2", "T4"): 6,
            ("T3", "T5"): 4,
            ("T4", "T5"): 4,
            ("T5", "T6"): 1,
        },
    },
    "urgent": {
        # Late-arriving urgent jobs: short front, long middle, moderate overlap.
        "durations": {
            "T1": 1, "T2": 2, "T3": 8, "T4": 5, "T5": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T3", "T4"),
            ("T4", "T5"),
        ],
        "delta_map": {
            ("T1", "T2"): 1,
            ("T2", "T3"): 2,
            ("T3", "T4"): 0,
            ("T4", "T5"): 0,
        },
    },
    "forkjoin": {
        "durations": {
            "T1": 2, "T2": 3, "T3": 6, "T4": 5, "T5": 6, "T6": 5, "T7": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T2", "T5"),
            ("T3", "T6"),
            ("T4", "T6"),
            ("T5", "T6"),
            ("T6", "T7"),
        ],
        "delta_map": {
            ("T1", "T2"): 0,
            ("T2", "T3"): 1,
            ("T2", "T4"): 0,
            ("T2", "T5"): 1,
            ("T3", "T6"): 0,
            ("T4", "T6"): 0,
            ("T5", "T6"): 0,
            ("T6", "T7"): 0,
        },
    },
}


def _scaled_duration(base, scale, jitter, rng):
    val = base * scale
    if jitter > 0:
        val += rng.randint(-jitter, jitter)
    return max(1, int(round(val)))


def create_job(job_id, release, archetype_name, config, rng):
    arch = ARCHETYPES[archetype_name]
    scale_low, scale_high = config.get("duration_scale_range", (1.0, 1.0))
    scale = rng.uniform(scale_low, scale_high)
    scale *= config.get("archetype_scale", {}).get(archetype_name, 1.0)
    jitter = config.get("task_jitter", 0)

    heavy_jobs = set(config.get("heavy_jobs", []))
    heavy_multiplier = config.get("heavy_multiplier", 1.0) if job_id in heavy_jobs else 1.0
    heavy_stage_names = set(config.get("heavy_stage_names", ("T3", "T4", "T5")))

    tasks = {}
    job = Job(job_id, release)
    for name, base_p in arch["durations"].items():
        p = _scaled_duration(base_p, scale, jitter, rng)
        if name in heavy_stage_names and job_id in heavy_jobs:
            p = max(1, int(round(p * heavy_multiplier)))
        tasks[name] = Task(f"{job_id}_{name}", job_id, p, release if name == "T1" else 0)

    uniform_delta = config.get("uniform_delta")
    overlap_multiplier = config.get("overlap_multiplier", 1.0)
    edge_delta_bias = config.get("edge_delta_bias", 0)
    late_urgent_bonus = config.get("late_urgent_bonus", 0)
    anchor_overlap_bias = config.get("anchor_overlap_bias", 0)
    trap_extra_overlap = config.get("trap_extra_overlap", 0)

    for src, dst in arch["edges"]:
        tasks[src].succ.append(tasks[dst])
        tasks[dst].pred.append(tasks[src])
        if uniform_delta is None:
            delta = arch["delta_map"].get((src, dst), 0)
        else:
            delta = uniform_delta
        delta = int(round(delta * overlap_multiplier)) + edge_delta_bias
        if archetype_name == "urgent":
            delta += late_urgent_bonus
        if archetype_name == "anchor":
            delta += anchor_overlap_bias
        if archetype_name == "trap":
            delta += trap_extra_overlap
        delta = max(0, min(delta, tasks[src].p - 1 if tasks[src].p > 1 else 0))
        tasks[src].delta_to_succ[tasks[dst]] = delta

    job.tasks = [tasks[name] for name in sorted(tasks.keys(), key=lambda x: int(x[1:]))]
    return job


def default_base_config():
    return {
        "machine_count": 2,
        # More conflict-heavy mix than V4.1:
        # 2 anchors compete with 2 traps, then urgent jobs arrive late and cut in.
        "job_plan": [
            {"job_id": "A", "archetype": "anchor", "release": 0},
            {"job_id": "B", "archetype": "trap", "release": 0},
            {"job_id": "C", "archetype": "anchor", "release": 2},
            {"job_id": "D", "archetype": "trap", "release": 2},
            {"job_id": "U", "archetype": "urgent", "release": 6},
            {"job_id": "V", "archetype": "urgent", "release": 8},
            {"job_id": "W", "archetype": "forkjoin", "release": 4},
        ],
        "release_jitter": 1,
        "duration_scale_range": (0.95, 1.1),
        "task_jitter": 1,
        "uniform_delta": None,
        "overlap_multiplier": 1.0,
        "edge_delta_bias": 0,
        "late_urgent_bonus": 0,
        "anchor_overlap_bias": 0,
        "trap_extra_overlap": 0,
        # Deterioration hits both anchor jobs so bottleneck shift matters more.
        "heavy_jobs": ["A", "C"],
        "heavy_multiplier": 1.22,
        "heavy_stage_names": ("T3", "T4", "T5", "T6"),
        "archetype_scale": {
            "anchor": 1.08,
            "trap": 1.02,
            "forkjoin": 1.0,
            "urgent": 0.95,
        },
        "deterioration_stage_names": ("T5", "T6"),
        "deterioration_target_job_ids": ("A", "C"),
    }


def create_jobs_from_config(config, seed=0):
    rng = random.Random(seed)
    jobs = []
    for spec in config["job_plan"]:
        jitter = rng.randint(0, config.get("release_jitter", 0)) if config.get("release_jitter", 0) > 0 else 0
        release = spec["release"] + jitter
        jobs.append(create_job(spec["job_id"], release, spec["archetype"], config, rng))
    return jobs


def apply_bottleneck_deterioration(jobs, factor=1.5, stage_names=("T5", "T6"), target_job_ids=None, seed=0):
    # Moderate regime: sometimes only one anchor is hit, sometimes both.
    rng = random.Random(seed)
    target_job_ids = list(target_job_ids or [])
    if target_job_ids:
        if factor <= 1.12:
            chosen = target_job_ids[:1]
        elif factor <= 1.28:
            chosen = target_job_ids[:]
        elif factor <= 1.42:
            chosen = target_job_ids[:]
        else:
            chosen = target_job_ids[:]
    else:
        chosen = [job.id for job in jobs]

    for job in jobs:
        if job.id not in chosen:
            continue
        for task in job.tasks:
            suffix = task.id.split("_")[-1]
            if suffix in stage_names:
                local_factor = factor
                # add tiny asymmetry so the bottleneck shift is not perfectly symmetric
                if len(chosen) > 1 and job.id == chosen[-1]:
                    local_factor += 0.03
                task.p = max(1, int(round(task.p * local_factor)))

    # For moderate-to-high deterioration, urgent jobs also get slightly more overlap,
    # increasing the chance that static HEFT overcommits to trap jobs.
    if factor >= 1.18:
        for job in jobs:
            if job.id.startswith(("U", "V")):
                for task in job.tasks:
                    for succ, delta in list(task.delta_to_succ.items()):
                        task.delta_to_succ[succ] = min(task.p - 1 if task.p > 1 else 0, delta + 1)
