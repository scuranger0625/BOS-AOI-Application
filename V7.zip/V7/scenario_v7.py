import random
from model_v2 import Task, Job

# V4.3 / V7 idea:
# - Make trap jobs look longer under static downstream rank,
#   but much shorter under overlap-aware D.
# - Keep a late urgent stream that BOS should pull forward earlier.
# - Reduce randomness slightly so the BOS-vs-HEFT separation is not washed out.

ARCHETYPES = {
    "anchor": {
        # Real bottleneck chain: almost no overlap, long merge pressure.
        "durations": {
            "T1": 1, "T2": 4, "T3": 14, "T4": 13, "T5": 12, "T6": 6,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T3", "T5"),
            ("T4", "T5"),
            ("T5", "T6"),
        ],
        "delta_map": {
            ("T1", "T2"): 0,
            ("T2", "T3"): 0,
            ("T2", "T4"): 0,
            ("T3", "T5"): 0,
            ("T4", "T5"): 0,
            ("T5", "T6"): 0,
        },
    },
    "trap": {
        # Static rank sees a long downstream chain.
        # BOS sees that the heavy middle can overlap a lot, so effective pressure is much smaller.
        "durations": {
            "T1": 1, "T2": 7, "T3": 18, "T4": 17, "T5": 5, "T6": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T3", "T5"),
            ("T4", "T5"),
            ("T5", "T6"),
        ],
        "delta_map": {
            ("T1", "T2"): 0,
            ("T2", "T3"): 12,
            ("T2", "T4"): 12,
            ("T3", "T5"): 4,
            ("T4", "T5"): 4,
            ("T5", "T6"): 0,
        },
    },
    "urgent": {
        # Arrives after early choices have already committed machines.
        # Enough weight that BOS should not leave it waiting too long.
        "durations": {
            "T1": 1, "T2": 2, "T3": 10, "T4": 7, "T5": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T3", "T4"),
            ("T4", "T5"),
        ],
        "delta_map": {
            ("T1", "T2"): 1,
            ("T2", "T3"): 4,
            ("T3", "T4"): 0,
            ("T4", "T5"): 0,
        },
    },
}


def _scaled_duration(base, scale, jitter, rng):
    val = base * scale
    if jitter > 0:
        val += rng.randint(-jitter, jitter)
    return max(1, int(round(val)))


def create_job(job_id, release, archetype_name, config, rng):
    arch = ARCHETYPES[archetype_name]
    scale_low, scale_high = config.get("duration_scale_range", (1.0, 1.0))
    scale = rng.uniform(scale_low, scale_high)
    scale *= config.get("archetype_scale", {}).get(archetype_name, 1.0)
    jitter = config.get("task_jitter", 0)

    tasks = {}
    job = Job(job_id, release)
    for name, base_p in arch["durations"].items():
        p = _scaled_duration(base_p, scale, jitter, rng)
        tasks[name] = Task(f"{job_id}_{name}", job_id, p, release if name == "T1" else 0)

    overlap_multiplier = config.get("overlap_multiplier", 1.0)
    edge_delta_bias = config.get("edge_delta_bias", 0)
    late_urgent_bonus = config.get("late_urgent_bonus", 0)
    trap_extra_overlap = config.get("trap_extra_overlap", 0)

    for src, dst in arch["edges"]:
        tasks[src].succ.append(tasks[dst])
        tasks[dst].pred.append(tasks[src])

        delta = arch["delta_map"].get((src, dst), 0)
        delta = int(round(delta * overlap_multiplier)) + edge_delta_bias
        if archetype_name == "urgent":
            delta += late_urgent_bonus
        if archetype_name == "trap":
            delta += trap_extra_overlap
        delta = max(0, min(delta, tasks[src].p - 1 if tasks[src].p > 1 else 0))
        tasks[src].delta_to_succ[tasks[dst]] = delta

    job.tasks = [tasks[name] for name in sorted(tasks.keys(), key=lambda x: int(x[1:]))]
    return job


def default_base_config():
    return {
        "machine_count": 2,
        # Two anchors + two traps + two late urgent jobs.
        # This is intentionally narrower than V6 so the priority-rule effect is easier to see.
        "job_plan": [
            {"job_id": "A", "archetype": "anchor", "release": 0},
            {"job_id": "B", "archetype": "trap", "release": 0},
            {"job_id": "C", "archetype": "anchor", "release": 1},
            {"job_id": "D", "archetype": "trap", "release": 1},
            {"job_id": "U", "archetype": "urgent", "release": 4},
            {"job_id": "V", "archetype": "urgent", "release": 6},
        ],
        "release_jitter": 1,
        "duration_scale_range": (0.97, 1.03),
        "task_jitter": 0,
        "overlap_multiplier": 1.0,
        "edge_delta_bias": 0,
        "late_urgent_bonus": 0,
        "trap_extra_overlap": 0,
        "archetype_scale": {
            "anchor": 1.0,
            "trap": 1.0,
            "urgent": 1.0,
        },
        # Keep deterioration focused on the real bottleneck jobs.
        "deterioration_stage_names": ("T5",),
        "deterioration_target_job_ids": ("A", "C"),
    }


def create_jobs_from_config(config, seed=0):
    rng = random.Random(seed)
    jobs = []
    for spec in config["job_plan"]:
        jitter = rng.randint(0, config.get("release_jitter", 0)) if config.get("release_jitter", 0) > 0 else 0
        release = spec["release"] + jitter
        jobs.append(create_job(spec["job_id"], release, spec["archetype"], config, rng))
    return jobs


def apply_bottleneck_deterioration(jobs, factor=1.15, stage_names=("T5",), target_job_ids=None, seed=0):
    target_job_ids = list(target_job_ids or [])
    chosen = target_job_ids[:] if target_job_ids else [job.id for job in jobs]

    for job in jobs:
        if job.id not in chosen:
            continue
        for task in job.tasks:
            suffix = task.id.split("_")[-1]
            if suffix in stage_names:
                local_factor = factor
                if len(chosen) > 1 and job.id == chosen[-1]:
                    local_factor += 0.02
                task.p = max(1, int(round(task.p * local_factor)))

    # When anchors deteriorate, urgent jobs become even more worth pulling forward.
    if factor >= 1.12:
        for job in jobs:
            if job.id.startswith(("U", "V")):
                for task in job.tasks:
                    for succ, delta in list(task.delta_to_succ.items()):
                        task.delta_to_succ[succ] = min(task.p - 1 if task.p > 1 else 0, delta + 1)
