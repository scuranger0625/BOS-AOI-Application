def compute_D_dynamic(task, memo):
    if task in memo:
        return memo[task]

    active_succ = [s for s in task.succ if s.status != "done"]

    if not active_succ:
        memo[task] = task.p
        task.D = task.p
        return task.D

    max_val = 0
    for succ in active_succ:
        delta = task.delta_to_succ.get(succ, 0)
        val = compute_D_dynamic(succ, memo) - delta
        max_val = max(max_val, val)

    memo[task] = task.p + max_val
    task.D = memo[task]
    return task.D


def bos_v5_select(ready_tasks):
    """
    改進點：
    - 每次 selection 只算 ready tasks + downstream
    - 避免全圖重算
    - 更接近 residual-aware
    """

    memo = {}

    for t in ready_tasks:
        compute_D_dynamic(t, memo)

    ready_tasks.sort(key=lambda x: (-x.D, x.ready_since, x.id))
    return ready_tasks[0]