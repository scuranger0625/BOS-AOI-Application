from scheduler_bos_v2 import bos_select
from scheduler_fifo_v2 import fifo_select
from model_v2 import Machine


class Simulator:
    def __init__(self, jobs, policy="FIFO", machine_count=2, verbose=True):
        self.jobs = jobs
        self.policy = policy
        self.time = 0
        self.verbose = verbose

        self.machines = [Machine(f"M{i + 1}") for i in range(machine_count)]
        self.all_tasks = [task for job in jobs for task in job.tasks]

    def log(self, message):
        if self.verbose:
            print(message)

    def all_done(self):
        return all(task.status == "done" for task in self.all_tasks)

    def process_completions(self):
        for machine in self.machines:
            task = machine.current_task
            if task is None:
                continue

            if task.finish_time == self.time:
                task.status = "done"
                machine.current_task = None

    def refresh_ready_tasks(self):
        ready = []
        for task in self.all_tasks:
            if task.is_ready(self.time):
                if task.status == "waiting":
                    task.status = "ready"
                    task.ready_since = self.time
                ready.append(task)
        return ready

    def select_task(self, ready_tasks):
        if self.policy == "BOS":
            return bos_select(ready_tasks)
        return fifo_select(ready_tasks)

    def assign(self, task, machine):
        task.status = "running"
        task.start_time = self.time
        task.finish_time = self.time + task.p
        task.assigned_machine = machine
        machine.current_task = task
        self.log(f"t={self.time} {task.id} -> {machine.id}")

    def next_event_time(self):
        candidate_times = []

        # Completion events of running tasks.
        for machine in self.machines:
            task = machine.current_task
            if task is not None and task.finish_time > self.time:
                candidate_times.append(task.finish_time)

        # Activation / release events of not-yet-started tasks.
        for task in self.all_tasks:
            if task.status not in ("waiting", "ready"):
                continue
            ready_t = task.earliest_ready_time()
            if ready_t is not None and ready_t > self.time:
                candidate_times.append(ready_t)

        if not candidate_times:
            return None
        return min(candidate_times)

    def run(self):
        while not self.all_done():
            self.process_completions()

            while True:
                ready = self.refresh_ready_tasks()
                idle_machines = [m for m in self.machines if m.current_task is None]

                if not ready or not idle_machines:
                    break

                task = self.select_task(ready)
                machine = idle_machines[0]
                self.assign(task, machine)

            if self.all_done():
                break

            next_time = self.next_event_time()
            if next_time is None:
                raise RuntimeError(
                    "Simulation is stuck: no future activation/completion event exists."
                )
            self.time = next_time

        makespan = max(task.finish_time for task in self.all_tasks)
        self.log(f"\nMakespan = {makespan}")
        return makespan
