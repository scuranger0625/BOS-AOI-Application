from scenario_v2 import create_jobs
from simulator_v2 import Simulator

print("===== FIFO V2 =====")
jobs = create_jobs()
sim = Simulator(jobs, policy="FIFO")
sim.run()

print("\n===== BOS V2 =====")
jobs = create_jobs()
sim = Simulator(jobs, policy="BOS")
sim.run()
