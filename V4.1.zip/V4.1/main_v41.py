
from copy import deepcopy
from statistics import mean
from pathlib import Path

from scenario_v41 import default_base_config, create_jobs_from_config, apply_bottleneck_deterioration
from simulator_v4 import Simulator
from report_v4 import ensure_dir, write_csv, write_json, build_summary, plot_overlap_sweep, plot_deterioration


POLICIES = ["FIFO", "HEFT", "BOS"]
SEEDS = [11, 19, 27, 35, 43, 51, 59]
# These are overlap multipliers / biases over the archetype-specific base deltas.
OVERLAP_MULTIPLIERS = [0.0, 0.5, 1.0, 1.5]
DETERIORATION_FACTORS = [1.0, 1.15, 1.35, 1.6]


def run_single(policy, jobs, machine_count, experiment_name, seed, config):
    sim = Simulator(jobs, policy=policy, machine_count=machine_count, verbose=False)
    makespan = sim.run()
    summary = build_summary(sim, experiment_name=experiment_name, seed=seed, config=config)
    summary["makespan"] = makespan
    return sim, summary


def print_policy_table(title, rows, group_key, value_key="avg_makespan"):
    print(f"\n=== {title} ===")
    grouped = {}
    for row in rows:
        grouped.setdefault(row[group_key], []).append(row)
    for key in sorted(grouped.keys()):
        print(f"\n{group_key} = {key}")
        for row in grouped[key]:
            util = row.get("avg_utilization", row.get("machine_utilization", "-"))
            imp = row.get("vs_fifo_improvement_pct")
            imp_txt = f" | vs FIFO: {imp}%" if imp is not None else ""
            print(
                f"  {row['policy']:<5} | {value_key}: {row[value_key]:>6}"
                f" | utilization: {util}{imp_txt}"
            )


def print_snapshot_results(snapshots):
    print("\n=== V4.1 Snapshot Case Results ===")
    for summary in snapshots:
        print(
            f"  {summary['policy']:<5} | makespan: {summary['makespan']:>3}"
            f" | utilization: {summary['machine_utilization']}"
        )


def add_fifo_gap(rows, group_key):
    grouped = {}
    for row in rows:
        grouped.setdefault(row[group_key], {})[row["policy"]] = row
    for _, item in grouped.items():
        fifo = item.get("FIFO")
        if not fifo:
            continue
        fifo_ms = fifo["avg_makespan"]
        for row in item.values():
            row["vs_fifo_improvement_pct"] = round((fifo_ms - row["avg_makespan"]) / fifo_ms * 100, 2) if fifo_ms else 0.0
    return rows


def overlap_sweep(output_dir):
    detail_rows = []
    agg_rows = []
    base = default_base_config()
    for overlap_multiplier in OVERLAP_MULTIPLIERS:
        cfg = deepcopy(base)
        cfg["overlap_multiplier"] = overlap_multiplier
        # Make urgent jobs gain relatively more overlap as multiplier grows.
        cfg["late_urgent_bonus"] = 1 if overlap_multiplier >= 1.0 else 0
        for policy in POLICIES:
            result_rows = []
            for seed in SEEDS:
                jobs = create_jobs_from_config(cfg, seed=seed)
                _, summary = run_single(policy, jobs, cfg["machine_count"], "overlap_sweep_v41", seed, cfg)
                row = {
                    "experiment": "overlap_sweep_v41",
                    "seed": seed,
                    "policy": policy,
                    "overlap_multiplier": overlap_multiplier,
                    "makespan": summary["makespan"],
                    "machine_utilization": summary["machine_utilization"],
                }
                detail_rows.append(row)
                result_rows.append(row)
            agg_rows.append({
                "experiment": "overlap_sweep_v41",
                "policy": policy,
                "overlap_multiplier": overlap_multiplier,
                "avg_makespan": round(mean(r["makespan"] for r in result_rows), 4),
                "avg_utilization": round(mean(r["machine_utilization"] for r in result_rows), 4),
            })
    agg_rows = add_fifo_gap(agg_rows, "overlap_multiplier")
    write_csv(detail_rows, output_dir / "overlap_sweep_detail.csv")
    write_csv(agg_rows, output_dir / "overlap_sweep_summary.csv")
    # Reuse plot function by adapting key names.
    plot_rows = [
        {"policy": row["policy"], "uniform_delta": row["overlap_multiplier"], "avg_makespan": row["avg_makespan"]}
        for row in agg_rows
    ]
    plot_overlap_sweep(plot_rows, output_dir / "overlap_sweep.png")
    return detail_rows, agg_rows


def deterioration_sweep(output_dir):
    detail_rows = []
    agg_rows = []
    base = default_base_config()
    base["overlap_multiplier"] = 1.0
    for factor in DETERIORATION_FACTORS:
        for policy in POLICIES:
            result_rows = []
            for seed in SEEDS:
                jobs = create_jobs_from_config(base, seed=seed)
                apply_bottleneck_deterioration(
                    jobs,
                    factor=factor,
                    stage_names=base["deterioration_stage_names"],
                    target_job_id=base["deterioration_target_job_id"],
                )
                _, summary = run_single(policy, jobs, base["machine_count"], "deterioration_sweep_v41", seed, {
                    **base,
                    "deterioration_factor": factor,
                })
                row = {
                    "experiment": "deterioration_sweep_v41",
                    "seed": seed,
                    "policy": policy,
                    "deterioration_factor": factor,
                    "makespan": summary["makespan"],
                    "machine_utilization": summary["machine_utilization"],
                }
                detail_rows.append(row)
                result_rows.append(row)
            agg_rows.append({
                "experiment": "deterioration_sweep_v41",
                "policy": policy,
                "deterioration_factor": factor,
                "avg_makespan": round(mean(r["makespan"] for r in result_rows), 4),
                "avg_utilization": round(mean(r["machine_utilization"] for r in result_rows), 4),
            })
    agg_rows = add_fifo_gap(agg_rows, "deterioration_factor")
    write_csv(detail_rows, output_dir / "deterioration_detail.csv")
    write_csv(agg_rows, output_dir / "deterioration_summary.csv")
    plot_deterioration(agg_rows, output_dir / "deterioration_sweep.png")
    return detail_rows, agg_rows


def snapshot_case(output_dir):
    cfg = default_base_config()
    cfg["overlap_multiplier"] = 1.0
    cfg["late_urgent_bonus"] = 1
    snapshots = []
    for policy in POLICIES:
        sim, summary = run_single(
            policy,
            create_jobs_from_config(cfg, seed=11),
            cfg["machine_count"],
            "snapshot_case_v41",
            11,
            cfg,
        )
        summary["policy"] = policy
        snapshots.append(summary)
        write_csv(sim.build_task_records(), output_dir / f"snapshot_{policy.lower()}_tasks.csv")
        write_csv(sim.assignment_log, output_dir / f"snapshot_{policy.lower()}_assignments.csv")
        write_json(sim.decision_log, output_dir / f"snapshot_{policy.lower()}_decisions.json")
    write_json(snapshots, output_dir / "snapshot_case_summary.json")
    return snapshots


def main():
    output_dir = ensure_dir(Path("v4_1_outputs"))
    _, overlap_summary = overlap_sweep(output_dir)
    _, deterioration_summary = deterioration_sweep(output_dir)
    snapshots = snapshot_case(output_dir)

    final_summary = {
        "policies": POLICIES,
        "seeds": SEEDS,
        "overlap_multipliers": OVERLAP_MULTIPLIERS,
        "deterioration_factors": DETERIORATION_FACTORS,
        "overlap_sweep_summary": overlap_summary,
        "deterioration_summary": deterioration_summary,
        "snapshot_case": snapshots,
    }
    write_json(final_summary, output_dir / "v4_1_summary.json")

    print_snapshot_results(snapshots)
    print_policy_table("V4.1 Overlap Sweep Summary", overlap_summary, group_key="overlap_multiplier")
    print_policy_table("V4.1 Deterioration Sweep Summary", deterioration_summary, group_key="deterioration_factor")
    print(f"\nV4.1 outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
