
import random
from copy import deepcopy
from model_v2 import Task, Job


# V4.1 idea:
# - Mix multiple DAG archetypes instead of repeating one 6-stage template.
# - Create "trap" jobs with long static downstream rank but generous overlap,
#   which can mislead static HEFT-like ranking.
# - Create low-overlap merge-heavy jobs whose bottleneck pressure is more real.
# - Add late-arrival urgent jobs to amplify contention on a small machine pool.

ARCHETYPES = {
    "anchor": {
        "durations": {
            "T1": 2, "T2": 4, "T3": 8, "T4": 7, "T5": 6, "T6": 3, "T7": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T3", "T5"),
            ("T4", "T5"),
            ("T5", "T6"),
            ("T6", "T7"),
        ],
        # Low overlap on the true heavy path.
        "delta_map": {
            ("T1", "T2"): 0,
            ("T2", "T3"): 0,
            ("T2", "T4"): 0,
            ("T3", "T5"): 0,
            ("T4", "T5"): 0,
            ("T5", "T6"): 0,
            ("T6", "T7"): 0,
        },
    },
    "trap": {
        "durations": {
            "T1": 2, "T2": 4, "T3": 9, "T4": 8, "T5": 5, "T6": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T3", "T5"),
            ("T4", "T5"),
            ("T5", "T6"),
        ],
        # Large overlap on the long branches. Static HEFT-like ranking ignores this,
        # while BOS discounts these edges.
        "delta_map": {
            ("T1", "T2"): 1,
            ("T2", "T3"): 4,
            ("T2", "T4"): 4,
            ("T3", "T5"): 3,
            ("T4", "T5"): 3,
            ("T5", "T6"): 1,
        },
    },
    "urgent": {
        "durations": {
            "T1": 1, "T2": 2, "T3": 6, "T4": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T3", "T4"),
        ],
        # Urgent jobs can overlap into the long middle stage quickly.
        "delta_map": {
            ("T1", "T2"): 1,
            ("T2", "T3"): 2,
            ("T3", "T4"): 0,
        },
    },
    "forkjoin": {
        "durations": {
            "T1": 2, "T2": 3, "T3": 5, "T4": 5, "T5": 5, "T6": 4, "T7": 2,
        },
        "edges": [
            ("T1", "T2"),
            ("T2", "T3"),
            ("T2", "T4"),
            ("T2", "T5"),
            ("T3", "T6"),
            ("T4", "T6"),
            ("T5", "T6"),
            ("T6", "T7"),
        ],
        "delta_map": {
            ("T1", "T2"): 0,
            ("T2", "T3"): 1,
            ("T2", "T4"): 0,
            ("T2", "T5"): 1,
            ("T3", "T6"): 0,
            ("T4", "T6"): 0,
            ("T5", "T6"): 0,
            ("T6", "T7"): 0,
        },
    },
}


def _scaled_duration(base, scale, jitter, rng):
    val = base * scale
    if jitter > 0:
        val += rng.randint(-jitter, jitter)
    return max(1, int(round(val)))


def create_job(job_id, release, archetype_name, config, rng):
    arch = ARCHETYPES[archetype_name]
    scale_low, scale_high = config.get("duration_scale_range", (1.0, 1.0))
    scale = rng.uniform(scale_low, scale_high)
    jitter = config.get("task_jitter", 0)

    heavy_jobs = set(config.get("heavy_jobs", []))
    branch_heavy = config.get("heavy_multiplier", 1.0) if job_id in heavy_jobs else 1.0

    # Optional per-archetype extra scaling.
    archetype_scale = config.get("archetype_scale", {}).get(archetype_name, 1.0)
    scale *= archetype_scale

    job = Job(job_id, release)
    tasks = {}
    for name, base_p in arch["durations"].items():
        p = _scaled_duration(base_p, scale, jitter, rng)
        # Push up the merge-heavy / bottleneck stages for designated heavy jobs.
        if name in config.get("heavy_stage_names", ("T3", "T4", "T5")) and job_id in heavy_jobs:
            p = max(1, int(round(p * branch_heavy)))
        tasks[name] = Task(f"{job_id}_{name}", job_id, p, release if name == "T1" else 0)

    uniform_delta = config.get("uniform_delta")
    edge_delta_bias = config.get("edge_delta_bias", 0)
    overlap_multiplier = config.get("overlap_multiplier", 1.0)
    late_urgent_bonus = config.get("late_urgent_bonus", 0)

    for src, dst in arch["edges"]:
        tasks[src].succ.append(tasks[dst])
        tasks[dst].pred.append(tasks[src])
        if uniform_delta is None:
            delta = arch["delta_map"].get((src, dst), 0)
        else:
            delta = uniform_delta
        delta = int(round(delta * overlap_multiplier)) + edge_delta_bias
        if archetype_name == "urgent":
            delta += late_urgent_bonus
        delta = max(0, min(delta, tasks[src].p - 1 if tasks[src].p > 1 else 0))
        tasks[src].delta_to_succ[tasks[dst]] = delta

    job.tasks = [tasks[name] for name in sorted(tasks.keys(), key=lambda x: int(x[1:]))]
    return job


def default_base_config():
    return {
        "machine_count": 2,
        # Mixed archetypes are the main change in V4.1.
        "job_plan": [
            {"job_id": "A", "archetype": "anchor", "release": 0},
            {"job_id": "B", "archetype": "trap", "release": 1},
            {"job_id": "C", "archetype": "forkjoin", "release": 3},
            {"job_id": "U", "archetype": "urgent", "release": 6},
            {"job_id": "V", "archetype": "urgent", "release": 9},
        ],
        "release_jitter": 1,
        "duration_scale_range": (0.95, 1.08),
        "task_jitter": 1,
        "uniform_delta": None,
        "edge_delta_bias": 0,
        "overlap_multiplier": 1.0,
        "late_urgent_bonus": 0,
        "heavy_jobs": ["A"],
        "heavy_multiplier": 1.25,
        "heavy_stage_names": ("T3", "T4", "T5", "T6"),
        "archetype_scale": {
            "anchor": 1.08,
            "trap": 1.0,
            "forkjoin": 1.0,
            "urgent": 0.95,
        },
        "deterioration_stage_names": ("T5", "T6"),
        "deterioration_target_job_id": "A",
    }


def create_jobs_from_config(config, seed=0):
    rng = random.Random(seed)
    jobs = []
    for spec in config["job_plan"]:
        base_release = spec["release"]
        jitter = rng.randint(0, config.get("release_jitter", 0)) if config.get("release_jitter", 0) > 0 else 0
        release = base_release + jitter
        jobs.append(create_job(spec["job_id"], release, spec["archetype"], config, rng))
    return jobs


def apply_bottleneck_deterioration(jobs, factor=1.5, stage_names=("T5", "T6"), target_job_id=None):
    for job in jobs:
        if target_job_id is not None and job.id != target_job_id:
            continue
        for task in job.tasks:
            suffix = task.id.split("_")[-1]
            if suffix in stage_names:
                task.p = max(1, int(round(task.p * factor)))
